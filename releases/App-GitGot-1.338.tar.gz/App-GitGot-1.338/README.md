# got

A tool to make it easier to manage multiple code repositories using different VCSen

# VERSION [![CPAN version](https://badge.fury.io/pl/App-GitGot.svg)](http://badge.fury.io/pl/App-GitGot)

# BUILD INFO

[![Build Status](https://travis-ci.org/genehack/app-gitgot.svg?branch=main)](https://travis-ci.org/genehack/app-gitgot)
[![Coverage Status](https://coveralls.io/repos/genehack/app-gitgot/badge.svg?branch=main)](https://coveralls.io/r/genehack/app-gitgot?branch=main)

# USAGE

See usage information [on CPAN](https://metacpan.org/pod/distribution/App-GitGot/bin/got)
